/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import math.Addition;

/**
 *
 * @author Romy
 */
public class AdditionTest {
    
    protected Addition op;
 
    @Before
    public void setUp() {
        op = new Addition();
    }
 
    @After
    public void tearDown() {
    }
 
    @Test
    public void testCalculer() throws Exception {
        assertEquals(new Long(4), op.calculer(new Long(1),
                                              new
Long(3)));
    }
 
    @Test
    public void testLireSymbole() throws Exception {
        assertEquals((Character)'+', op.lireSymbole());
    }
}

        //Comme vous pouvez le constater, Maven produit un rapport de tests 
        //en mode textuel avec la synthèse du nombre de tests et la liste des 
        //tests en échec. Par défaut Maven produit les rapports détaillés dans 
        //le dossier target/surefire-reports.
    
